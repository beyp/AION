"""AION System Tray module."""
