"""AION Notifications module."""
