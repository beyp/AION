"""Gestionnaire de notifications AION - Toast Windows + logs."""
import logging
from typing import Any

logger = logging.getLogger(__name__)


class AionNotifier:
    """
    Gestionnaire de notifications pour AION.

    Supporte les notifications toast Windows (win10toast).
    Les notifications peuvent etre activees/desactivees via le systray
    ou directement via enable() / disable().

    Usage:
        notifier = AionNotifier()
        notifier.notify("Titre", "Message")
        notifier.enabled = False  # desactiver
    """

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled
        self._toaster = None
        self._init_toaster()

    def _init_toaster(self) -> None:
        """Initialise le toaster Windows si disponible."""
        try:
            from win10toast import ToastNotifier
            self._toaster = ToastNotifier()
            logger.debug("Notifier: win10toast initialise")
        except ImportError:
            logger.warning(
                "Notifier: win10toast non disponible - "
                "installez-le avec: pip install win10toast"
            )
            self._toaster = None

    def notify(
        self,
        title: str,
        message: str,
        duration: int = 5,
        icon_path: str | None = None,
    ) -> None:
        """
        Envoie une notification toast Windows.

        Args:
            title:     Titre de la notification.
            message:   Corps du message.
            duration:  Duree d affichage en secondes.
            icon_path: Chemin vers une icone .ico (optionnel).
        """
        logger.info("Notification: [%s] %s", title, message)

        if not self.enabled:
            logger.debug("Notifier: notifications desactivees, skipped.")
            return

        if self._toaster is None:
            logger.debug("Notifier: toaster non disponible, skipped.")
            return

        try:
            self._toaster.show_toast(
                title=title,
                msg=message,
                icon_path=icon_path,
                duration=duration,
                threaded=True,
            )
        except Exception as exc:
            logger.error("Notifier: erreur lors de l envoi du toast: %s", exc)

    def notify_alert(self, message: str) -> None:
        """Notification d alerte (priorite haute)."""
        self.notify("⚠️ AION Alert", message, duration=8)

    def notify_info(self, message: str) -> None:
        """Notification d information."""
        self.notify("🤖 AION", message, duration=4)

    def toggle(self) -> bool:
        """Bascule l etat des notifications. Retourne le nouvel etat."""
        self.enabled = not self.enabled
        state = "activees" if self.enabled else "desactivees"
        logger.info("Notifier: notifications %s", state)
        return self.enabled

    @property
    def available(self) -> bool:
        """Indique si win10toast est disponible."""
        return self._toaster is not None
