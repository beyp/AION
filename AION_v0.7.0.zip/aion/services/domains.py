"""
Registre des domaines de services AION.

Nomenclature : <domaine>_<action>
Exemple      : net_ping, sys_cpu, docker_status

Pour ajouter un domaine :
  - Via la console AION  : domain add <nom> <description>
  - Via ce fichier       : ajouter une entree dans DOMAINS
"""

DOMAINS: dict[str, str] = {
    "net":    "Services reseau (ping, IP, status, DNS...)",
    "sys":    "Services systeme (CPU, RAM, disque, uptime...)",
    "docker": "Services Docker (conteneurs, images, volumes...)",
    "ai":     "Services IA (ollama, embeddings, generation...)",
    "fs":     "Services fichiers (backup, sync, scan...)",
    "svc":    "Services applicatifs (web, api, daemon...)",
    "demo":   "Services de demonstration et de test",
}


def get_domain(service_name: str) -> str | None:
    """Extrait le domaine d un nom de service (ex: net_ping -> net)."""
    parts = service_name.split("_", 1)
    if len(parts) >= 2:
        return parts[0]
    return None


def is_valid_domain(domain: str) -> bool:
    """Verifie si un domaine est enregistre."""
    return domain in DOMAINS


def add_domain(name: str, description: str) -> bool:
    """Ajoute un nouveau domaine au registre."""
    if name in DOMAINS:
        return False
    DOMAINS[name] = description
    return True


def list_domains() -> dict[str, str]:
    """Retourne tous les domaines enregistres."""
    return dict(DOMAINS)
